#!/usr/bin/env python

import base_filters

COPY_GOOGLE_DOC_KEY = '1FwRh41h458JmMsT6sv7_kLrV_G_jtVdwoUw6tPJ4-90'

USE_ASSETS = False

# Use these variables to override the default cache timeouts for this graphic
# DEFAULT_MAX_AGE = 20
# ASSETS_MAX_AGE = 300

JINJA_FILTER_FUNCTIONS = base_filters.FILTERS
